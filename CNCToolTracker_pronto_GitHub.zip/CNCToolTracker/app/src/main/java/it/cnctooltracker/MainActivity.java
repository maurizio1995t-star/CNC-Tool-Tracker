package it.cnctooltracker;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.*;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout list;
    private TextView summary;
    private int dark = Color.rgb(31, 36, 43);
    private int accent = Color.rgb(217, 119, 6);
    private int ink = Color.rgb(31, 41, 55);
    private int muted = Color.rgb(107, 114, 128);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("cnc_tools", MODE_PRIVATE);
        getWindow().setStatusBarColor(dark);
        getWindow().setNavigationBarColor(dark);
        getWindow().getDecorView().setSystemUiVisibility(0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 247, 250));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(18), dp(18), dp(18), dp(16));
        header.setBackgroundColor(dark);

        TextView title = new TextView(this);
        title.setText("CNC TOOL TRACKER");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        header.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Gestione utensili · Tornio CNC a 24 postazioni");
        subtitle.setTextColor(Color.rgb(203, 213, 225));
        subtitle.setTextSize(13);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(5);
        header.addView(subtitle, subLp);

        summary = new TextView(this);
        summary.setTextColor(Color.WHITE);
        summary.setTextSize(14);
        summary.setPadding(0, dp(14), 0, 0);
        header.addView(summary);
        root.addView(header);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), dp(12), dp(16), dp(8));
        TextView section = new TextView(this);
        section.setText("POSTAZIONI UTENSILI");
        section.setTextColor(ink);
        section.setTypeface(null, Typeface.BOLD);
        section.setTextSize(14);
        bar.addView(section, new LinearLayout.LayoutParams(0, -2, 1));
        TextView saveHint = new TextView(this);
        saveHint.setText("Salvataggio automatico");
        saveHint.setTextColor(muted);
        saveHint.setTextSize(11);
        bar.addView(saveHint);
        root.addView(bar);

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(2), dp(12), dp(20));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        buildRows();
        updateSummary();
    }

    private void buildRows() {
        list.removeAllViews();
        for (int i = 1; i <= 24; i++) {
            final int n = i;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(10));
            card.setBackground(rounded(Color.WHITE, Color.rgb(226, 232, 240), 12));
            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
            cardLp.bottomMargin = dp(9);
            list.addView(card, cardLp);

            LinearLayout heading = new LinearLayout(this);
            heading.setGravity(Gravity.CENTER_VERTICAL);
            TextView station = new TextView(this);
            station.setText(String.format(java.util.Locale.ITALY, "POSTAZIONE %02d", n));
            station.setTextColor(ink);
            station.setTextSize(15);
            station.setTypeface(null, Typeface.BOLD);
            heading.addView(station, new LinearLayout.LayoutParams(0, -2, 1));
            TextView status = new TextView(this);
            status.setTextSize(11);
            status.setPadding(dp(9), dp(5), dp(9), dp(5));
            status.setTag("status" + n);
            heading.addView(status);
            card.addView(heading);

            EditText name = new EditText(this);
            name.setSingleLine(true);
            name.setTextSize(14);
            name.setTextColor(ink);
            name.setHint("Nome / descrizione utensile");
            name.setHintTextColor(Color.rgb(156, 163, 175));
            name.setPadding(dp(10), 0, dp(10), 0);
            name.setBackground(rounded(Color.rgb(248, 250, 252), Color.rgb(226, 232, 240), 8));
            name.setImeOptions(EditorInfo.IME_ACTION_DONE);
            name.setText(prefs.getString("name_" + n, ""));
            LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(-1, dp(46));
            nameLp.topMargin = dp(10);
            card.addView(name, nameLp);
            name.addTextChangedListener(new android.text.TextWatcher() {
                public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                public void onTextChanged(CharSequence s, int st, int before, int count) {
                    prefs.edit().putString("name_" + n, s.toString()).apply();
                }
                public void afterTextChanged(android.text.Editable e) {}
            });

            LinearLayout checks = new LinearLayout(this);
            checks.setOrientation(LinearLayout.VERTICAL);
            checks.setPadding(0, dp(5), 0, 0);
            CheckBox mounted = new CheckBox(this);
            mounted.setText("Utensile montato");
            mounted.setTextColor(ink);
            mounted.setTextSize(14);
            mounted.setButtonTintList(android.content.res.ColorStateList.valueOf(accent));
            mounted.setChecked(prefs.getBoolean("mounted_" + n, false));
            CheckBox zeroed = new CheckBox(this);
            zeroed.setText("Utensile azzerato");
            zeroed.setTextColor(ink);
            zeroed.setTextSize(14);
            zeroed.setButtonTintList(android.content.res.ColorStateList.valueOf(Color.rgb(22, 163, 74)));
            zeroed.setChecked(prefs.getBoolean("zeroed_" + n, false));
            zeroed.setEnabled(mounted.isChecked());
            checks.addView(mounted);
            checks.addView(zeroed);
            card.addView(checks);

            mounted.setOnCheckedChangeListener((button, checked) -> {
                prefs.edit().putBoolean("mounted_" + n, checked)
                    .putBoolean("zeroed_" + n, checked && zeroed.isChecked()).apply();
                if (!checked) {
                    zeroed.setChecked(false);
                    zeroed.setEnabled(false);
                } else {
                    zeroed.setEnabled(true);
                }
                updateStatus(status, mounted.isChecked(), zeroed.isChecked());
                updateSummary();
            });
            zeroed.setOnCheckedChangeListener((button, checked) -> {
                if (checked && !mounted.isChecked()) {
                    zeroed.setChecked(false);
                    return;
                }
                prefs.edit().putBoolean("zeroed_" + n, checked).apply();
                updateStatus(status, mounted.isChecked(), zeroed.isChecked());
                updateSummary();
            });
            updateStatus(status, mounted.isChecked(), zeroed.isChecked());
        }
    }

    private void updateStatus(TextView status, boolean mounted, boolean zeroed) {
        if (mounted && zeroed) {
            status.setText("PRONTO");
            status.setTextColor(Color.rgb(21, 128, 61));
            status.setBackground(rounded(Color.rgb(220, 252, 231), Color.rgb(187, 247, 208), 30));
        } else if (mounted) {
            status.setText("DA AZZERARE");
            status.setTextColor(Color.rgb(180, 83, 9));
            status.setBackground(rounded(Color.rgb(254, 243, 199), Color.rgb(253, 230, 138), 30));
        } else {
            status.setText("DA MONTARE");
            status.setTextColor(muted);
            status.setBackground(rounded(Color.rgb(243, 244, 246), Color.rgb(229, 231, 235), 30));
        }
    }

    private void updateSummary() {
        int mounted = 0, zeroed = 0;
        for (int i = 1; i <= 24; i++) {
            if (prefs.getBoolean("mounted_" + i, false)) mounted++;
            if (prefs.getBoolean("mounted_" + i, false) && prefs.getBoolean("zeroed_" + i, false)) zeroed++;
        }
        summary.setText("Montati: " + mounted + "/24     Azzerati: " + zeroed + "/24");
    }

    private GradientDrawable rounded(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
