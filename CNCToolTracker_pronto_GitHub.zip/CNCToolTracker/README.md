# CNC Tool Tracker

App Android semplice per tenere traccia degli utensili su un tornio CNC con 24 postazioni.

## Funzioni
- 24 postazioni numerate
- Campo nome/descrizione utensile per ogni postazione
- Checkbox "Utensile montato" e "Utensile azzerato"
- L'azzeramento è selezionabile solo quando l'utensile è montato
- Salvataggio locale automatico con SharedPreferences
- Funziona offline; nessun permesso Internet richiesto

## Come ottenere l'APK
1. Installa Android Studio sul PC.
2. Apri la cartella `CNCToolTracker` in Android Studio.
3. Attendi la sincronizzazione Gradle (richiede connessione la prima volta per scaricare il plugin Android Gradle).
4. Seleziona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. L'APK di debug sarà generato in `app/build/outputs/apk/debug/app-debug.apk`.

Requisiti: Android Studio recente e Android SDK Platform 35.

## Compilazione online senza PC (GitHub Actions)
Il progetto include `.github/workflows/build-apk.yml` per compilare l'APK su GitHub Actions.
1. Carica il contenuto di questa cartella in un repository GitHub (puoi farlo dal browser del telefono).
2. Apri la scheda **Actions** del repository e abilita le Actions se richiesto.
3. Seleziona **Build CNC Tool Tracker APK** e premi **Run workflow** (un push sul branch main/master avvia anche la compilazione).
4. Al termine, apri la run completata e scarica l'artifact **CNC-Tool-Tracker-APK**. Dentro troverai `app-debug.apk`.
